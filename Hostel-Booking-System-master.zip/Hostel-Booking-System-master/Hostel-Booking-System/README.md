Hello Everyone,
    This Project is completely based on Booking a Hostel through Online
    This Project is done by using Basic Html,CSS and JavaScript
